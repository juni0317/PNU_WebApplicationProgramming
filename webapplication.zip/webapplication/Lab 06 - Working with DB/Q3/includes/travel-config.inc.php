<?php
define('DBCONNECTION', 'mysql:host=localhost;dbname=travels');
define('DBUSER', 'root');
define('DBPASS', '');

//type your dbname, username, password
