<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_id = $_POST['id'];
    $input_password = $_POST['password'];
    
    // 미리 설정된 계정 정보와 비교
    $valid_id = "testuser";
    $valid_password = "mypassword";
    
    if ($input_id === $valid_id && $input_password === $valid_password) {
        // 로그인 성공
        $_SESSION['logged_in'] = true;
        header("Location: data.php"); // 카테고리 목록 페이지로 리다이렉트
        exit();
    } else {
        // 로그인 실패
        echo "<hr><p>ID or Password is incorrect!</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form method="POST" action="">
        ID: <input type="text" name="id"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>