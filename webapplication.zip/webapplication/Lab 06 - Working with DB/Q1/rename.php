<?php
	$connString = "mysql:host=localhost;dbname=bookrepo";
	$user = "root";
	$pass = "";

	$pdo = new PDO($connString, $user, $pass);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	#
	# TODO 2: fill out the following two lines of code
	#
	$from = $_POST['old']; # your code goes here
	$to = $_POST['new']; # your code goes here

	$sql = "UPDATE Categories SET CategoryName='$to' WHERE CategoryName='$from'";
	$count = $pdo->exec($sql);

	$pdo = null;

	echo "<p>Updated ".$count." rows</p>";
?>
<meta http-equiv="refresh" content="3;url=index.php" />