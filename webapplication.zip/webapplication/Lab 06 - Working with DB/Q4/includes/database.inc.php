<?php

// 참고. 필요한 경우, 함수의 인자/파라미터를 변경해도 됨

function setConnectionInfo($values) {
    try {
        $pdo = new PDO(DBCONNECTION, DBUSER, DBPASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
        return null;
    }
}

function runQuery($pdo, $sql, $parameters = []) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($parameters);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Query failed: ' . $e->getMessage();
        return null;
    }
}

function readAllCustomers() {
    $pdo = setConnectionInfo([DBCONNECTION]);
    $sql = "SELECT * FROM Customers";
    return runQuery($pdo, $sql,);
}

function readSelectCustomers($lastName) {
    $pdo = setConnectionInfo([DBCONNECTION]);
    $sql = "SELECT * FROM Customers WHERE LastName = :lastName";
    $params = [':lastName' => $lastName];
    return runQuery($pdo, $sql, $params);
}

function readCategories() {
    $pdo = setConnectionInfo([DBCONNECTION]);
    $sql = "SELECT * FROM Categories";
    return runQuery($pdo, $sql);
}

function readImprints() {
    $pdo = setConnectionInfo([DBCONNECTION]);
    $sql = "SELECT * FROM Imprints";
    return runQuery($pdo, $sql);
}
?>