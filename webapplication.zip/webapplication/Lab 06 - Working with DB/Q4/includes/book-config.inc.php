<?php

define('DBCONNECTION', 'mysql:host=localhost; dbname=books');
define('DBUSER', 'root');
define('DBPASS', '');

?>
