<?php
	$email = "randy@abc.net";
	$password = "zxzx";
?>