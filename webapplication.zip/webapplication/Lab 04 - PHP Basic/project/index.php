<?php

include_once "travel-data.php";


function generateLink($url, $label, $class = null) {
    $classAttribute = $class ? "class='$class'" : "";
    return "<a href='$url' $classAttribute>$label</a>";
}


function outputPostRow($number) {
    global ${"postId" . $number}, ${"thumb" . $number}, ${"title" . $number};
    global ${"userName" . $number}, ${"userId" . $number}, ${"date" . $number}, ${"excerpt" . $number};

    $postLink = 'post.php?id=' . ${"postId" . $number};
    $image = '<img src="images/travel/' . ${"thumb" . $number} . '" alt="' . ${"title" . $number} . '" class="img-thumbnail"/>';
    $user = utf8_encode(${"userName" . $number});
    $userLink = generateLink("user.php?id=" . ${"userId" . $number}, $user);

    echo '<div class="row">';
    echo '<div class="col-md-2">';
    echo generateLink($postLink, $image);
    echo '</div>';
    echo '<div class="col-md-10">';
    echo '<h2>' . ${"title" . $number} . '</h2>';
    echo '<div class="details">';
    echo 'Posted by ' . $userLink;
    echo '<span class="pull-right">' . ${"date" . $number} . '</span>';
    echo '</div>';
    echo '<p class="excerpt">' . ${"excerpt" . $number} . '</p>';
    echo '<p>' . generateLink($postLink, 'Read more', 'btn btn-primary btn-sm') . '</p>';
    echo '</div>';
    echo '</div>';
}

function outputPagination($startNum, $currentNum) {
    echo '<ul class="pagination">';
    $disabled = ($startNum <= 1) ? ' class="disabled"' : '';
    echo '<li' . $disabled . '>' . generateLink("#", "&laquo;") . '</li>';

    $number = $startNum;
    for ($i = 0; $i < 10; $i++) {
        $active = ($number == $currentNum) ? ' class="active"' : '';
        echo '<li' . $active . '>';
        echo generateLink('#', $number);
        echo '</li>';
        $number++;
    }

    echo '<li><a href="#">&raquo;</a></li>';
    echo '</ul>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Travel Template</title>
    <link href="bootstrap3_travelTheme/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap3_travelTheme/theme.css" rel="stylesheet">
</head>
<body>
    <!-- Header 포함 -->
    <?php include 'travel-header.php'; ?>

    <div class="container">
        <div class="row">
            <!-- Left Navigation Rail -->
            <div class="col-md-3">
                <?php include 'travel-left-rail.php'; ?>
            </div>

            <!-- Main Content Area -->
            <div class="col-md-9">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Browse</a></li>
                    <li class="active">Posts</li>
                </ol>

                <div class="jumbotron" id="postJumbo">
                    <h1>Posts</h1>
                    <p>Read other travellers' posts ... or create your own.</p>
                    <p><a class="btn btn-warning btn-lg">Learn more &raquo;</a></p>
                </div>

                <div class="postlist">
                    <?php
                    for ($i = 1; $i <= 3; $i++) {
                        outputPostRow($i);
                        if ($i < 3) {
                            echo "<hr />";
                        }
                    }
                    ?>
                </div>

                <?php outputPagination(1, 4); ?>
            </div>
        </div>
    </div>

    <!-- Footer 포함 -->
    <?php include 'travel-footer.php'; ?>

    <!-- JavaScript Files -->
    <script src="bootstrap3_travelTheme/assets/js/jquery.js"></script>
    <script src="bootstrap3_travelTheme/dist/js/bootstrap.min.js"></script>
</body>
</html>
