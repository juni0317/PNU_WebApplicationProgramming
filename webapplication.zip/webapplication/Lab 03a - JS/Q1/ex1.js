function highlight() {
	document.getElementById("content").style.background = 'yellow';
}

function off() {
	document.getElementById("content").style.background = 'white';
}
