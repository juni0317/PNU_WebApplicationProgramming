<?php
// POST 방식으로 전달된 데이터 받기
$name = $_POST['name'];
$language = $_POST['language'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>POST Request Result</title>
    <style>
        table {
            border: 1px solid black;
        }
        td {
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <h3>POST value(s):</h3>
    <table>
        <tr>
            <td>Name</td>
            <td><?php echo htmlspecialchars($name); ?></td>
        </tr>
        <tr>
            <td>Language</td>
            <td><?php echo htmlspecialchars($language); ?></td>
        </tr>
    </table>
</body>
</html>